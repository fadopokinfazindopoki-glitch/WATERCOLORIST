package com.ondasreais.mixin;

import net.minecraft.entity.Entity;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.registry.tag.FluidTags;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import net.minecraft.world.explosion.Explosion;
import net.minecraft.world.explosion.ExplosionBehavior;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * Quando uma explosão de TNT acontece perto de água, espalha partículas
 * de respingo/bolha pra todo lado a partir do centro da explosão.
 *
 * De propósito, isso é só um efeito visual (não cria blocos de água
 * novos) — assim não existe o risco de uma TNT "inundar" sua
 * construção sem querer.
 *
 * AVISO: este é o único arquivo do mod que depende de um nome de
 * método "colado" no bytecode (um Mixin). Se ele não aplicar na sua
 * versão (erro no console mencionando "ondasreais" e "createExplosion"
 * ao iniciar o jogo), o resto do mod continua funcionando normalmente
 * — é só esse respingo de TNT que não vai aparecer. Me mande o erro
 * que aparecer no log que eu ajusto.
 */
@Mixin(World.class)
public abstract class ExplosionWaterMixin {

    @Inject(
            method = "createExplosion(Lnet/minecraft/entity/Entity;Lnet/minecraft/entity/damage/DamageSource;"
                    + "Lnet/minecraft/world/explosion/ExplosionBehavior;DDDFZLnet/minecraft/world/World$ExplosionSourceType;)"
                    + "Lnet/minecraft/world/explosion/Explosion;",
            at = @At("RETURN")
    )
    private void ondasreais$aoExplodir(Entity entity, DamageSource damageSource, ExplosionBehavior behavior,
                                        double x, double y, double z, float power, boolean createFire,
                                        World.ExplosionSourceType explosionSourceType,
                                        CallbackInfoReturnable<Explosion> cir) {
        World self = (World) (Object) this;
        if (self.isClient || !(self instanceof ServerWorld world)) {
            return;
        }
        if (explosionSourceType != World.ExplosionSourceType.TNT) {
            return;
        }

        BlockPos centro = BlockPos.ofFloored(x, y, z);
        int raio = Math.max(3, Math.round(power * 2));
        boolean achouAgua = false;

        buscaAgua:
        for (int dx = -raio; dx <= raio; dx++) {
            for (int dy = -raio; dy <= raio; dy++) {
                for (int dz = -raio; dz <= raio; dz++) {
                    if (world.getFluidState(centro.add(dx, dy, dz)).isIn(FluidTags.WATER)) {
                        achouAgua = true;
                        break buscaAgua;
                    }
                }
            }
        }

        if (!achouAgua) {
            return;
        }

        int quantidade = 40 + raio * 10;
        for (int i = 0; i < quantidade; i++) {
            double ang = world.getRandom().nextDouble() * Math.PI * 2;
            double dist = world.getRandom().nextDouble() * raio;
            double px = x + Math.cos(ang) * dist;
            double pz = z + Math.sin(ang) * dist;
            double py = y + (world.getRandom().nextDouble() - 0.2) * 1.5;
            double vx = Math.cos(ang) * (0.4 + world.getRandom().nextDouble());
            double vz = Math.sin(ang) * (0.4 + world.getRandom().nextDouble());
            double vy = 0.3 + world.getRandom().nextDouble() * 0.6;

            world.spawnParticles(ParticleTypes.SPLASH, px, py, pz, 0, vx, vy, vz, 1.0);
            if (i % 3 == 0) {
                world.spawnParticles(ParticleTypes.BUBBLE, px, py - 0.3, pz, 0, vx * 0.5, 0.1, vz * 0.5, 1.0);
            }
        }
    }
}
