package com.ondasreais.wave;

import net.minecraft.block.Block;
import net.minecraft.block.Blocks;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.tag.FluidTags;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;

import java.util.HashSet;
import java.util.Set;

/**
 * Representa a área de água ao redor de UMA engrenagem.
 *
 * A cada tick ela calcula, para cada coluna (x,z) dentro do raio, uma
 * "altura de onda" com uma soma de senos. Essa altura vira um número de
 * camadas de água de verdade acima do nível normal da água (ou do chão,
 * nas bordas — e é exatamente aí que a onda "transborda" para fora
 * d'água, em cima da terra).
 *
 * Só mexemos em blocos que nós mesmos colocamos (guardados em
 * "blocosControlados"), então a engrenagem nunca destrói construções
 * do jogador: se um bloco esperado estiver ocupado por outra coisa,
 * aquela camada é simplesmente ignorada.
 */
public class WavePool {

    // Ajuste estes números à vontade:
    private static final int RAIO = 8;              // alcance horizontal, em blocos
    private static final int INTENSIDADE_MAXIMA = 5; // camadas extras possíveis no máximo
    private static final int COLUNAS_POR_TICK = 40;  // espalha o custo ao longo de vários ticks
    private static final double VELOCIDADE = 0.07;   // velocidade da onda

    private final RegistryKey<World> dimensao;
    private final BlockPos centro;
    private final int baseY;
    private int intensidade;
    private long idade = 0;
    private int indiceColuna = 0;

    private final Set<BlockPos> blocosControlados = new HashSet<>();

    private WavePool(RegistryKey<World> dimensao, BlockPos centro, int baseY, int intensidade) {
        this.dimensao = dimensao;
        this.centro = centro;
        this.baseY = baseY;
        this.intensidade = intensidade;
    }

    public static WavePool criarAoRedorDe(ServerWorld world, BlockPos gearPos, int intensidade) {
        int baseY = detectarNivelDaAgua(world, gearPos);
        return new WavePool(world.getRegistryKey(), gearPos, baseY, intensidade);
    }

    private static int detectarNivelDaAgua(ServerWorld world, BlockPos gearPos) {
        BlockPos.Mutable cursor = gearPos.mutableCopy();
        for (int dy = 0; dy >= -6; dy--) {
            cursor.setY(gearPos.getY() + dy);
            if (world.getFluidState(cursor).isIn(FluidTags.WATER)) {
                return cursor.getY();
            }
        }
        // Não achou água perto: usa o chão logo abaixo da engrenagem,
        // assim ela ainda funciona (como uma fonte de onda) em terreno seco.
        return gearPos.getY() - 1;
    }

    public void setIntensidade(int novaIntensidade) {
        this.intensidade = Math.max(0, Math.min(INTENSIDADE_MAXIMA, novaIntensidade));
    }

    public RegistryKey<World> getDimensao() {
        return dimensao;
    }

    public void tick(ServerWorld world) {
        idade++;

        if (intensidade <= 0) {
            // Mar calmo: recolhe qualquer água extra que ainda esteja em pé.
            recolherTudo(world);
            return;
        }

        int lado = RAIO * 2 + 1;
        int totalColunas = lado * lado;
        int processadas = 0;

        while (processadas < COLUNAS_POR_TICK && processadas < totalColunas) {
            int idx = (indiceColuna + processadas) % totalColunas;
            int dx = (idx % lado) - RAIO;
            int dz = (idx / lado) - RAIO;
            processarColuna(world, dx, dz);
            processadas++;
        }
        indiceColuna = (indiceColuna + processadas) % totalColunas;
    }

    private void processarColuna(ServerWorld world, int dx, int dz) {
        int x = centro.getX() + dx;
        int z = centro.getZ() + dz;

        double onda = (Math.sin(x * 0.45 + idade * VELOCIDADE)
                + Math.sin(z * 0.38 - idade * (VELOCIDADE * 0.8) + dx * 0.2)) / 2.0; // -1..1
        double normalizada = (onda + 1) / 2.0; // 0..1
        int camadasAlvo = (int) Math.round(normalizada * intensidade);

        // Importante: o loop vai sempre até INTENSIDADE_MAXIMA (não até
        // "intensidade"), senão, quando o jogador abaixa a intensidade,
        // as camadas mais altas que já existiam nunca seriam revisitadas
        // para recolher a água de volta.
        for (int camada = 1; camada <= INTENSIDADE_MAXIMA; camada++) {
            BlockPos pos = new BlockPos(x, baseY + camada, z);
            boolean deveTerAgua = camada <= camadasAlvo;
            aplicarCamada(world, pos, deveTerAgua);
        }
    }

    private void aplicarCamada(ServerWorld world, BlockPos pos, boolean deveTerAgua) {
        boolean controlado = blocosControlados.contains(pos);

        if (deveTerAgua) {
            if (controlado) {
                return; // já é água nossa, nada a fazer
            }
            if (world.getBlockState(pos).isAir()) {
                world.setBlockState(pos, Blocks.WATER.getDefaultState(), Block.NOTIFY_LISTENERS);
                blocosControlados.add(pos.toImmutable());
            }
            // Se não é ar (o jogador construiu algo ali), ignora essa camada.
        } else if (controlado) {
            // Só removemos se ainda for a água que nós colocamos — se o
            // jogador substituiu por outro bloco, deixamos quieto.
            if (world.getBlockState(pos).isOf(Blocks.WATER)) {
                world.setBlockState(pos, Blocks.AIR.getDefaultState(), Block.NOTIFY_LISTENERS);
            }
            blocosControlados.remove(pos);
        }
    }

    private void recolherTudo(ServerWorld world) {
        if (blocosControlados.isEmpty()) {
            return;
        }
        for (BlockPos pos : new HashSet<>(blocosControlados)) {
            if (world.getBlockState(pos).isOf(Blocks.WATER)) {
                world.setBlockState(pos, Blocks.AIR.getDefaultState(), Block.NOTIFY_LISTENERS);
            }
        }
        blocosControlados.clear();
    }

    public void limpar(ServerWorld world) {
        recolherTudo(world);
    }
}
