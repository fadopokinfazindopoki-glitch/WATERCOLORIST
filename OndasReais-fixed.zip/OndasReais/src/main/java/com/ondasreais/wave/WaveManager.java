package com.ondasreais.wave;

import com.ondasreais.OndasReais;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;

import java.util.HashMap;
import java.util.Map;

/**
 * Registro central de todas as "engrenagens de onda" ativas no mundo.
 * Cada engrenagem tem uma WavePool associada que, a cada tick do
 * servidor, sobe e desce colunas de água de verdade ao redor dela.
 *
 * Isto não é uma simulação de fluido real (o motor do Minecraft não
 * suporta isso) — é uma aproximação por blocos que usa água e ar de
 * verdade, então ela renderiza, transborda e flutua barcos como água
 * normal do jogo.
 */
public final class WaveManager {
    private WaveManager() {}

    private static final Map<BlockPos, WavePool> POOLS = new HashMap<>();

    public static void registerGear(World world, BlockPos gearPos, int intensidade) {
        if (world.isClient || !(world instanceof ServerWorld serverWorld)) {
            return;
        }
        POOLS.computeIfAbsent(gearPos.toImmutable(), pos -> WavePool.criarAoRedorDe(serverWorld, pos, intensidade));
    }

    public static void setIntensity(BlockPos gearPos, int intensidade) {
        WavePool pool = POOLS.get(gearPos);
        if (pool != null) {
            pool.setIntensidade(intensidade);
        }
    }

    public static void removeGear(World world, BlockPos gearPos) {
        WavePool pool = POOLS.remove(gearPos.toImmutable());
        if (pool != null && world instanceof ServerWorld serverWorld) {
            pool.limpar(serverWorld);
        }
    }

    public static void clear() {
        POOLS.clear();
    }

    public static void tick(MinecraftServer server) {
        if (POOLS.isEmpty()) {
            return;
        }
        for (Map.Entry<BlockPos, WavePool> entry : POOLS.entrySet()) {
            try {
                ServerWorld world = server.getWorld(entry.getValue().getDimensao());
                if (world == null) {
                    continue;
                }
                int chunkX = entry.getKey().getX() >> 4;
                int chunkZ = entry.getKey().getZ() >> 4;
                if (!world.getChunkManager().isChunkLoaded(chunkX, chunkZ)) {
                    continue;
                }
                entry.getValue().tick(world);
            } catch (Exception e) {
                // Não deixa um erro numa piscina derrubar o tick inteiro do servidor.
                OndasReais.LOGGER.warn("[Ondas Reais] Falha ao atualizar uma piscina de onda", e);
            }
        }
    }
}
