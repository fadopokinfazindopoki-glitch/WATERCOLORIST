package com.ondasreais;

import com.ondasreais.block.ModBlocks;
import com.ondasreais.wave.WaveManager;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Ponto de entrada do mod "Ondas Reais".
 *
 * O que este mod faz, em resumo:
 *  - Adiciona um bloco "Engrenagem das Ondas" que o jogador coloca perto
 *    (ou dentro) da água.
 *  - Clicar com o botão direito na engrenagem aumenta a intensidade das
 *    ondas ao redor dela (0 a 5). Em 0, o mar fica parado.
 *  - A cada tick do servidor, colunas de água de verdade sobem e descem
 *    num padrão de onda. Perto da praia, isso faz a água "transbordar"
 *    para cima da terra — e depois recuar.
 *  - Barcos flutuam nessa água normalmente, então acabam balançando
 *    com a onda sem precisarmos mexer no código do barco.
 *  - Uma explosão de TNT perto de água espalha partículas de respingo
 *    pra todo lado (ver ExplosionWaterMixin).
 */
public class OndasReais implements ModInitializer {

    public static final String MOD_ID = "ondasreais";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    @Override
    public void onInitialize() {
        LOGGER.info("[Ondas Reais] Inicializando...");

        ModBlocks.registerAll();

        // A cada tick do servidor, atualiza todas as "piscinas de onda" ativas.
        ServerTickEvents.END_SERVER_TICK.register(WaveManager::tick);

        // Ao fechar o mundo, esquece as piscinas (evita misturar com o próximo mundo).
        ServerLifecycleEvents.SERVER_STOPPED.register(server -> WaveManager.clear());

        LOGGER.info("[Ondas Reais] Pronto.");
    }
}
