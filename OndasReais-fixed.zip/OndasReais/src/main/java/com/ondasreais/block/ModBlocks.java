package com.ondasreais.block;

import com.ondasreais.OndasReais;
import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.minecraft.block.AbstractBlock;
import net.minecraft.block.Block;
import net.minecraft.block.entity.BlockEntityType;
import net.minecraft.block.MapColor;
import net.minecraft.item.BlockItem;
import net.minecraft.item.Item;
import net.minecraft.item.ItemGroups;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.util.Identifier;

/**
 * Registro central dos blocos/itens do mod.
 *
 * Mantido simples de propósito: se alguma linha aqui não compilar na
 * sua versão exata do Fabric API, normalmente é só comparar com o que
 * a sua IDE sugere no autocomplete (os nomes de método e classe mudam
 * um pouquinho entre versões do Minecraft).
 */
public final class ModBlocks {
    private ModBlocks() {}

    public static final Block WAVE_GEAR = new WaveGearBlock(
            AbstractBlock.Settings.create()
                    .mapColor(MapColor.STONE_GRAY)
                    .strength(2.5f)
                    .requiresTool()
                    .nonOpaque()
    );

    public static BlockEntityType<WaveGearBlockEntity> WAVE_GEAR_ENTITY;
    public static Item WAVE_GEAR_ITEM;

    public static void registerAll() {
        Registry.register(
                Registries.BLOCK,
                new Identifier(OndasReais.MOD_ID, "wave_gear"),
                WAVE_GEAR
        );

        WAVE_GEAR_ITEM = Registry.register(
                Registries.ITEM,
                new Identifier(OndasReais.MOD_ID, "wave_gear"),
                new BlockItem(WAVE_GEAR, new Item.Settings())
        );

        WAVE_GEAR_ENTITY = Registry.register(
                Registries.BLOCK_ENTITY_TYPE,
                new Identifier(OndasReais.MOD_ID, "wave_gear"),
                BlockEntityType.Builder.create(WaveGearBlockEntity::new, WAVE_GEAR).build(null)
        );

        // Coloca o item na aba de criativa de Redstone, junto de outros mecanismos.
        ItemGroupEvents.modifyEntriesEvent(ItemGroups.REDSTONE)
                .register(entries -> entries.add(WAVE_GEAR_ITEM));
    }
}
