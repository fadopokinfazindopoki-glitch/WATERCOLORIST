package com.ondasreais.block;

import net.minecraft.block.Block;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.block.BlockEntityProvider;
import net.minecraft.block.BlockState;
import net.minecraft.block.entity.BlockEntityTicker;
import net.minecraft.block.entity.BlockEntityType;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import org.jetbrains.annotations.Nullable;

/**
 * A "engrenagem das ondas": o jogador coloca perto da água e clica com
 * o botão direito pra subir a intensidade das ondas ao redor (0 a 5).
 *
 * Toda a lógica de onda em si mora em WaveManager/WavePool — este
 * bloco só guarda a intensidade (via WaveGearBlockEntity) e avisa o
 * WaveManager quando ela muda.
 */
public class WaveGearBlock extends Block implements BlockEntityProvider {

    public WaveGearBlock(Settings settings) {
        super(settings);
    }

    @Nullable
    @Override
    public BlockEntity createBlockEntity(BlockPos pos, BlockState state) {
        return new WaveGearBlockEntity(pos, state);
    }

    @Nullable
    @Override
    @SuppressWarnings("unchecked")
    public <T extends BlockEntity> BlockEntityTicker<T> getTicker(World world, BlockState state, BlockEntityType<T> type) {
        if (world.isClient) {
            return null;
        }
        return (w, pos, st, be) -> {
            if (be instanceof WaveGearBlockEntity gear) {
                gear.serverTick(w, pos);
            }
        };
    }

    @Override
    public ActionResult onUse(BlockState state, World world, BlockPos pos, PlayerEntity player, Hand hand, BlockHitResult hit) {
        if (world.isClient) {
            return ActionResult.SUCCESS;
        }
        if (world.getBlockEntity(pos) instanceof WaveGearBlockEntity gear) {
            int novaIntensidade = gear.cycleIntensity();
            world.playSound(null, pos, SoundEvents.BLOCK_ANVIL_STEP, SoundCategory.BLOCKS,
                    0.6f, 1.0f + novaIntensidade * 0.1f);
            player.sendMessage(Text.literal("Intensidade das ondas: " + novaIntensidade + "/5"), true);
            return ActionResult.CONSUME;
        }
        return ActionResult.PASS;
    }

    // Se este método não existir mais com esse nome exato na sua versão
    // (procure por "onStateReplaced" na classe Block pela sua IDE), o
    // único efeito é a água extra não ser "recolhida" automaticamente
    // ao quebrar a engrenagem — não afeta o resto do mod.
    @Override
    public void onStateReplaced(BlockState state, World world, BlockPos pos, BlockState newState, boolean moved) {
        if (!state.isOf(newState.getBlock())) {
            if (world.getBlockEntity(pos) instanceof WaveGearBlockEntity gear) {
                gear.limpar(world);
            }
        }
        super.onStateReplaced(state, world, pos, newState, moved);
    }
}
