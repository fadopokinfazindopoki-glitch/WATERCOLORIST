package com.ondasreais.block;

import com.ondasreais.wave.WaveManager;
import net.minecraft.block.BlockState;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;

public class WaveGearBlockEntity extends BlockEntity {

    public static final int INTENSIDADE_MAXIMA = 5;

    private int intensidade = 2;
    private boolean registradoNoWaveManager = false;

    public WaveGearBlockEntity(BlockPos pos, BlockState state) {
        super(ModBlocks.WAVE_GEAR_ENTITY, pos, state);
    }

    public int cycleIntensity() {
        intensidade = (intensidade + 1) % (INTENSIDADE_MAXIMA + 1);
        markDirty();
        WaveManager.setIntensity(pos, intensidade);
        return intensidade;
    }

    public void serverTick(World world, BlockPos pos) {
        if (!registradoNoWaveManager) {
            WaveManager.registerGear(world, pos, intensidade);
            registradoNoWaveManager = true;
        }
    }

    public void limpar(World world) {
        WaveManager.removeGear(world, pos);
    }

    @Override
    protected void writeNbt(NbtCompound nbt) {
        super.writeNbt(nbt);
        nbt.putInt("Intensidade", intensidade);
    }

    @Override
    public void readNbt(NbtCompound nbt) {
        super.readNbt(nbt);
        if (nbt.contains("Intensidade")) {
            intensidade = nbt.getInt("Intensidade");
        }
    }
}
